iSeeVideo M2.1 README

 1) unzip the file-contents into an appropriate directory
 2) rename iSeeVideo.exe to iSeeVideo@<ipaddress>-<port>.exe
    ex. iSeeVideo@192.168.0.1-8020.exe implies that the ucast server is running on 192.168.0.1 on port 8020
 3) run self-test to ensure audio/video works fine
 4) create the ip-address file in the server
 5) click on connect to connect to server
 6) then login to specific service and start using isee


